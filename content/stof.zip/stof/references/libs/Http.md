# HTTP Network Library (Http)
Functions for working with HTTP calls over a system network connection (async fetch, etc.). Off by default: the host opts in with `allow_http()` (Rust, Python) or `doc.allowHttp()` (JS), or allows only some hosts with `allow_http_hosts([...])` / `doc.allowHttp([...])`. Allowing any host means any public host: this machine and private networks (localhost, 10.x, 192.168.x, 169.254.x where cloud metadata services live, `*.internal`, ...) stay off limits, checked on every redirect too, unless the host lists them or calls `allow_private_network()` (Rust, Python) / `doc.allowPrivateNetwork()` (JS). Requires the "http" feature (native builds). The `stof` CLI enables it.

## Thread Pool
This library adds a thread pool in the background for processing HTTP requests, allowing Stof to keep running while requests are executed separately. Asyncronous fetch requests will create a new Stof process, which will wait for the thread pool to execute the request before returning a map with the response data. You can then await this response map when you need it, which significantly increases performance by enabling parallel HTTP requests.

# Http::blob(response: map) -> blob
Extract the body of this response as bytes.
```rust
const resp = await Http::fetch("https://restcountries.com/v3.1/region/europe");
const body = Http::blob(resp);
```

# Http::client_error(response: map) -> bool
Was the request a client error? Meaning, is the response 'status' between [400, 499]?
```rust
const resp = await Http::fetch("https://restcountries.com/v3.1/region/europe");
assert_not(Http::client_error(resp));
```

# async Http::fetch(url: str, method: str = "get", body: str | blob = null, headers: map = null, timeout: seconds = null, query: map = null, bearer: str = null) -> Promise<map>
Make an HTTP request, using the thread pool in the background so that other Stof processes can continue running.
```rust
const resp = await Http::fetch("https://restcountries.com/v3.1/region/europe");
assert(Http::text(resp).len() > 100); // response map: status, ok, headers, content_type, bytes
```

# Http::parse(response: map, context: obj = self) -> obj
Parse an HTTP response into the context object (also the return value), using the response "Content-Type" header as a Stof format (binary import). Default content type if not found in response headers is "stof". Will throw an error if the format isn't accepted by this graph, or if the body doesn't exist.
```rust
const resp = await Http::fetch("https://restcountries.com/v3.1/region/europe");
const body = new {};
try Http::parse(resp, body);
catch { /* didn't work out.. */ }
```

# Http::server_error(response: map) -> bool
Was the request a server error? Meaning, is the response 'status' between [500, 599]?
```rust
const resp = await Http::fetch("https://restcountries.com/v3.1/region/europe");
assert_not(Http::server_error(resp));
```

# Http::size(response: map) -> bytes
Extract the response body size in bytes.
```rust
const resp = await Http::fetch("https://restcountries.com/v3.1/region/europe");
const mib_body_size = Http::size(resp) as MiB;
```

# Http::success(response: map) -> bool
Was the request successful? Meaning, is the response 'status' between [200, 299]?
```rust
const resp = await Http::fetch("https://restcountries.com/v3.1/region/europe");
assert(Http::success(resp));
```

# Http::text(response: map) -> str
Extract a UTF-8 text body from this response map (Equivalent to Http::blob(response) as str).
```rust
const resp = await Http::fetch("https://restcountries.com/v3.1/region/europe");
const body = Http::text(resp);
```

